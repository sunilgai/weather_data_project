

# Test Endpoint
Endpoint: '/summary'\
Select order, region, parameter from the dropdowns to get filtered time-series weather-data

# Tech Stack used
- Django Rest framework
- mysql
- Docker

